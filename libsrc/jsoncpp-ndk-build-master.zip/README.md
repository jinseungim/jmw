jsoncpp-ndk-build
=================

build jsoncpp for android (armeabi armeabi-v7a x86)


How to build
=================
download [android ndk](https://developer.android.com/tools/sdk/ndk/index.html#download), choose Platform (32-bit target)

define ndk path in your environment.

build it:
```
cd path/to/jsoncpp-ndk-build
ndk-build
```
